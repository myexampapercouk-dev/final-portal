---
name: British Prep Specialist
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#584049'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#8b7079'
  outline-variant: '#debec9'
  surface-tint: '#b60471'
  primary: '#9b005f'
  on-primary: '#ffffff'
  primary-container: '#c2187a'
  on-primary-container: '#ffdee8'
  inverse-primary: '#ffb0cf'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#005c25'
  on-tertiary: '#ffffff'
  tertiary-container: '#007732'
  on-tertiary-container: '#84ff9b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9e5'
  primary-fixed-dim: '#ffb0cf'
  on-primary-fixed: '#3d0023'
  on-primary-fixed-variant: '#8c0055'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#7ffc97'
  tertiary-fixed-dim: '#62df7d'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005320'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 34px
    fontWeight: '800'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system serves a premier British independent prep and grammar school exam preparation ecosystem. Spanning three interconnected environments—Parent Portal, Teacher Portal, and Admin Portal—the visual language bridges rigorous academic excellence with approachable, child-positive encouragement.

The aesthetic blends **Modern Corporate Clarity** with purposeful, **Educational Tactile Warmth**:
- **Confidence & Academic Authority:** Clear, well-structured typographic hierarchies and crisp, high-contrast layouts convey elite educational pedigree for parents and schools preparing students for 7+, 8+, 11+, and 13+ entrance assessments.
- **Vibrant & Encouraging:** Bright chromatic accents (magenta, sky cyan, and spring lime) prevent clinical austerity, creating an inspiring, gamified, and optimistic learning dashboard.
- **Multirole Purpose:** Modular, clean white and slate surfaces maintain utilitarian rigor for tutors grading mock papers, deep analytics for administrators, and intuitive, stress-free tracking for parents.

## Colors

The palette is rooted in the identity of British prep education, anchored by clear functional roles:

- **Primary (`#C2187A` / `#D81B60` - Magenta):** The signature brand accent. Represents the core identity banner ("The School Specialist"). Used for primary action buttons, key milestone celebrations, active progress states, and 11+ flagship entrance exam badges.
- **Secondary (`#0284C7` / `#0EA5E9` - Sky Cyan):** Applied to secondary actions, instructional links, active portal navigation, calendar/scheduling cues, and 13+ Common Entrance badges.
- **Tertiary (`#16A34A` / `#84CC16` - Lime & Spring Green):** Conveys mastery, correct answers, pass thresholds, homework submission confirmations, and 7+/8+ junior badges.
- **Neutral Surface & Text (`#0F172A`, `#334155`, `#F8FAFC`, `#FFFFFF`):** High-readability slate and charcoal against optical white surfaces ensures long-form exam questions, rubric tables, and complex score breakdowns remain completely legible without eye fatigue.

### Exam Category Semantic Badges
- **7+ Junior:** `#65A30D` (Lime tint background: `#F7FEE7`, text: `#365314`, border: `#BEF264`)
- **8+ Junior:** `#0D9488` (Teal tint background: `#F0FDFA`, text: `#134E4A`, border: `#99F6E4`)
- **11+ Senior Prep:** `#C2187A` (Magenta tint background: `#FDF2F8`, text: `#831843`, border: `#FBCFE8`)
- **13+ Common Entrance:** `#0284C7` (Sky tint background: `#F0F9FF`, text: `#0C4A6E`, border: `#BAE6FD`)

## Typography

Typography balances pedagogical structure with contemporary ease:
- **Headlines & Badges (`Plus Jakarta Sans`):** Selected for its friendly geometric curves and welcoming humanist touches. Headings establish clear section boundaries across complex multi-step papers and tutor marking schemes without intimidating young learners.
- **Body & Exam Transcripts (`Inter`):** Engineered for sustained digital reading and rigorous tabular layout. High x-height, clear aperture differentiation, and standard numerical tabular alignments provide error-free presentation of comprehension passages, maths problems, and score matrices.

## Layout & Spacing

The portal layout adheres to a strict 12-column responsive fluid grid with fixed max-content containers:
- **Desktop (>=1280px):** 12 columns with `1.5rem` gutters and max 1440px page width. Sidebar navigation (Parent/Teacher/Admin) is persistent (260px width).
- **Tablet (768px - 1279px):** 8 columns with `1.25rem` gutters; sidebar collapses to an icon rail or off-canvas drawer.
- **Mobile (<768px):** 4 columns with `1rem` gutters and `1rem` outer canvas padding. Action buttons stretch to full width or lock to bottom floating utility bars.

Spacing follows an 8pt linear rhythm. Generous vertical breathing room (`space-xl`) between test sections prevents cognitive overload, while concise grouping (`space-sm` to `space-md`) within question cards and answer sheets keeps context unified.

## Elevation & Depth

Visual hierarchy uses a refined hybrid of **Tonal Surface Layering** and **Subtle Crisp Borders**, avoiding heavy synthetic drop shadows:

- **Surface Levels:** 
  - Canvas / Background: `#F8FAFC` (Cool Off-White)
  - Card / Panel Surface: `#FFFFFF` (Crisp Pure White)
  - Interactive Inset / Sub-card: `#F1F5F9` (Slate Light)
- **Outlines & Borders:** Cards and containers use an ultra-crisp 1px border (`#E2E8F0`). On focused or active elements, the border transitions cleanly to the respective role color (`#C2187A` or `#0284C7`) at 1.5px.
- **Ambient Shadows:**
  - *Resting Card Elevation:* `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`
  - *Hover / Dragged Mock Paper:* `0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)`
  - *Active Modal / Exam Timer Overlay:* `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.05)`

## Shapes

The shape system employs consistent **Rounded (Level 2)** geometry:
- **Base UI Elements (`rounded-md` - 8px / 0.5rem):** Form inputs, buttons, paper download tiles, score counters, and dropdown triggers.
- **Containers & Dashboard Cards (`rounded-lg` - 16px / 1rem):** Main exam modules, student report cards, and interactive test viewers.
- **Modals & Elevated Prompts (`rounded-xl` - 24px / 1.5rem):** Exam completion dialogues, payment confirmation panels, and tutor feedback drawers.
- **Badges & Progress Pills (`rounded-full`):** Category indicators (7+, 11+), timing countdown badges, and status pills.

## Components

### Buttons
- **Primary Action (Exam Start, Save Changes, Subscribe):** Solid `#C2187A` background, white label in `Plus Jakarta Sans` Semibold, 8px border radius, with a subtle hover state `#A21365` and active scale `0.98`.
- **Secondary Action (Mark Scheme, Download PDF, Filter):** Crisp white background, 1px `#CBD5E1` border, `#0F172A` text; on hover, border shifts to `#0284C7` with `#F0F9FF` background.
- **Tertiary / Ghost:** No border or background; slate `#475569` text, used in secondary pagination and dismiss actions.

### Badges & Category Chips
- Exam tier pills (7+, 8+, 11+, 13+) use a fixed height of 28px, 12px horizontal padding, uppercase `label-md` typography, and pill-shaped borders (`9999px`).
- Includes a dedicated 6px circular indicator dot matching the category accent color for fast scanning on crowded admin lists.

### Tabs & Exam View Navigation
- Segmented pill tabs on a `#F1F5F9` background container.
- Active tab features a solid `#FFFFFF` card surface, crisp shadow, and `#0F172A` bold text.
- Section step tabs (e.g., Section A: Comprehension, Section B: Creative Writing) display completion checkmarks in tertiary green `#16A34A`.

### Input Fields & Search Bars
- Background: `#FFFFFF` with a 1px border in `#CBD5E1`.
- Focus state: Outline-free, transitioning to a distinct 2px ring in primary `#C2187A` or sky blue `#0284C7` with `2px` offset.
- Labels sit cleanly above the field in `Plus Jakarta Sans` Medium (`label-lg`), with helper text in neutral slate `#64748B`.

### Checkboxes & Radio Buttons
- 20px by 20px with 6px border radius (checkboxes) and circular form (radios).
- Border: `#94A3B8`. Checked state: Solid `#C2187A` or `#0284C7` with a crisp white tick/dot.

### Exam Paper Cards
- Structured three-tier layout:
  1. *Header:* Exam badge (e.g., 11+ GL Assessment / ISEB), subject tag (Maths, English, Verbal Reasoning), and year.
  2. *Body:* Paper title, duration (e.g., "50 mins"), total marks, and difficulty level.
  3. *Footer:* Quick action buttons ("Practice Now", "Download PDF", "Teacher Review") separated by a fine hairline `#F1F5F9`.